#Project 2  - Social Network Mining
library(igraph)
setwd("C:/Users/anupams/OneDrive - Microsoft/Study/Summer 2018/Project 2")

fbData = read.table("Data/facebook_combined.txt")
print(fbData)

fbData = as.matrix(fbData)
fbData[,1] = as.character(fbData[,1])
fbData[,2] = as.character(fbData[,2])

fbGraph = graph_from_edgelist(fbData[,1:2], directed=FALSE)
node_size = rep(4, vcount(fbGraph))
#node_color = rep("blue", vcount(fbGraph))

#plot(fbGraph, vertex.size = node_size, vertex.color = node_color, vertex.label= NA, edge.arrow.size = 0, main="Plot of Facebook network")
plot(fbGraph, vertex.size = node_size, vertex.label= NA, edge.arrow.size = 0, main="Plot of Facebook network")
vcount(fbGraph)
ecount(fbGraph)

## question 1: Is Facebook Network Connected ?

is_connected(fbGraph)
count_components(fbGraph)
clusters(fbGraph)

## Question 2 Find the diameter of the Facebook Network
diameter(fbGraph)
get_diameter(fbGraph)
farthest_vertices(fbGraph)

## Question 3 Plot the Degree Distribtion of Facebook Network and report its Mean
deg = degree(fbGraph)
plot(degree.distribution(fbGraph),xlab = "Degree", ylab = "Frequency", pch=16, cex= 0.6, main ="Degree Distribution of Facebook Network")
#plot(degree(fbGraph),xlab = "Nodes", ylab = "Frequency", pch=16, cex= 0.6, main ="Degree per node for Facebook Network")
avgDeg = mean(deg)
avgDeg


## Question 4 - plotting Degree Distrubtion at Log-Log Scale
plot(degree.distribution(fbGraph),log="xy", xlab = "Degree(Log)", ylab = "Frequency( Log)", pch=16, cex= 0.6, main ="Log Scale Degree Distribution of Facebook Network")
xaxis = seq(14,200, by=1)
yaxis = xaxis^(-1.35)*1
lines(xaxis,yaxis, col="blue")
#plot(degree(fbGraph),log="xy", xlab = "Nodes(Log)", ylab = "Frequency( Log)", pch=16, cex= 0.6, main ="Log Scale Degrees per Node of Facebook Network")


