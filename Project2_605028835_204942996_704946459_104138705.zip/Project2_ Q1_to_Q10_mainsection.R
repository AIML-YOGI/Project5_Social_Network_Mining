library("igraph")
##----------------------Question 1----------------------------##
g1 <- read.graph("/Users/Patrick/ECE 232E/proj2/facebook_combined.txt", directed=FALSE)
is.connected(g1)#the network is connected
##----------------------Question 2----------------------------##
diameter(g1, directed=FALSE)#diameter=8
##----------------------Question 3----------------------------##
deg_distr <- degree.distribution(g1)
plot(deg_distr,main="Degree distribution of the Facebook network
     ",xlab="Degree",ylab="Frequency")
#find average degree
mean(degree(g1))#43.69101
##----------------------Question 4----------------------------##
x1 = log(seq(1:length(deg_distr)))
y1 = log(deg_distr)
is.na(y1) <- sapply(y1, is.infinite)
f1 <- lm(y1~x1)
plot(x1,y1, main="Degree distribution of the Facebook network in log-log scale
     ",xlab="log-degree",ylab="log-frequency")
#add fitted line
abline(f1,col="red")
#find slope
summary(f1)#slope=-1.2475

##----------------------Question 5----------------------------##
g2 <- induced_subgraph(g1, c(1, neighbors(g1,1)))
#find number of nodes
num_node = vcount(g2)
num_node#348 nodes
#find number of edges
num_edge = ecount(g2) 
num_edge #2866 edges
##----------------------Question 6----------------------------##
diameter(g2)
##----------------------Question 8----------------------------##
#find number of core nodes
corenodes <- which(neighborhood.size(g1,1,nodes=V(g1))>200)
length(corenodes)#40
#find average degree of hte core nodes
ave_deg <- mean(degree(g1, v=V(g1)[corenodes]))
ave_deg#279.375
##----------------------Question 9----------------------------##
#----------id=1-------------#
fg1 <- cluster_fast_greedy(g2)
modularity(fg1)#0.4131014
plot(g2, mark.groups=groups(fg1), edge.arrow.size=.5, 
     vertex.color=fg1$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Fast-Greedy (Node ID 1)")

eb1 <- cluster_edge_betweenness(g2)
modularity(eb1)#0.3533022
plot(g2, mark.groups=groups(eb1), edge.arrow.size=.5, 
     vertex.color=eb1$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Edge-Betweenness (Node ID 1)")

im1 <- cluster_infomap(g2)
modularity(im1)#0.3891185
plot(g2, mark.groups=groups(im1), edge.arrow.size=.5, 
     vertex.color=im1$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Infomap (Node ID 1)")

#----------id=108-------------#
g3 <- induced_subgraph(g1, c(108, neighbors(g1,108)))

fg2 <- cluster_fast_greedy(g3)
modularity(fg2)#0.4359294
plot(g3, mark.groups=groups(fg2), edge.arrow.size=.5, 
     vertex.color=fg2$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Fast-Greedy (Node ID 108)")

eb2 <- cluster_edge_betweenness(g3)
modularity(eb2)#0.5067549
plot(g3, mark.groups=groups(eb2), edge.arrow.size=.5, 
     vertex.color=eb2$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Edge-Betweenness (Node ID 108)")

im2 <- cluster_infomap(g3)
modularity(im2)#0.5082492
plot(g3, mark.groups=groups(im2), edge.arrow.size=.5, 
     vertex.color=im2$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Infomap (Node ID 108)")

#----------id=349-------------#
g4 <- induced_subgraph(g1, c(349, neighbors(g1,349)))

fg3 <- cluster_fast_greedy(g4)
modularity(fg3)#0.2517149
plot(g4, mark.groups=groups(fg3), edge.arrow.size=.5, 
     vertex.color=fg3$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Fast-Greedy (Node ID 349)")

eb3 <- cluster_edge_betweenness(g4)
modularity(eb3)#0.133528
plot(g4, mark.groups=groups(eb3), edge.arrow.size=.5, 
     vertex.color=eb3$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Edge-Betweenness (Node ID 349)")

im3 <- cluster_infomap(g4)
modularity(im3)#0.09602908
plot(g4, mark.groups=groups(im3), edge.arrow.size=.5, 
     vertex.color=im3$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Infomap (Node ID 349)")

#----------id=484-------------#
g5 <- induced_subgraph(g1, c(484, neighbors(g1,484)))

fg4 <- cluster_fast_greedy(g5)
modularity(fg4)#0.5070016
plot(g5, mark.groups=groups(fg4), edge.arrow.size=.5, 
     vertex.color=fg4$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Fast-Greedy (Node ID 484)")

eb4 <- cluster_edge_betweenness(g5)
modularity(eb4)#0.4890952
plot(g5, mark.groups=groups(eb4), edge.arrow.size=.5, 
     vertex.color=eb4$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Edge-Betweenness (Node ID 484)")

im4 <- cluster_infomap(g5)
modularity(im4)#0.5152788
plot(g5, mark.groups=groups(im4), edge.arrow.size=.5, 
     vertex.color=im4$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Infomap (Node ID 484)")

#----------id=1087-------------#
g6 <- induced_subgraph(g1, c(1087, neighbors(g1,1087)))

fg5 <- cluster_fast_greedy(g6)
modularity(fg5)#0.1455315
plot(g6, mark.groups=groups(fg5), edge.arrow.size=.5, 
     vertex.color=fg5$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Fast-Greedy (Node ID 1087)")

eb5 <- cluster_edge_betweenness(g6)
modularity(eb5)#0.02762377
plot(g6, mark.groups=groups(eb5), edge.arrow.size=.5, 
     vertex.color=eb5$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Edge-Betweenness (Node ID 1087)")

im5 <- cluster_infomap(g6)
modularity(im5)#0.02690662
plot(g6, mark.groups=groups(im5), edge.arrow.size=.5, 
     vertex.color=im5$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Infomap (Node ID 1087)")

##----------------------Question 10----------------------------##
#----------id=1-------------#
g2_del_core <- induced_subgraph(g1, neighbors(g1, 1))

fg1 <- cluster_fast_greedy(g2_del_core)
modularity(fg1)#0.4418533
plot(g2_del_core, mark.groups=groups(fg1), edge.arrow.size=.5, vertex.color=fg1$membership, vertex.label=NA, vertex.size=4, main="Community Structure using Fast-Greedy without core nodes (Node ID 1)")

eb1 <- cluster_edge_betweenness(g2_del_core)
modularity(eb1)#0.4161461
plot(g2_del_core, mark.groups=groups(eb1), edge.arrow.size=.5, 
     vertex.color=eb1$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Edge-Betweenness without core nodes (Node ID 1)")

im1 <- cluster_infomap(g2_del_core)
modularity(im1)#0.4180077
plot(g2_del_core, mark.groups=groups(im1), edge.arrow.size=.5, 
     vertex.color=im1$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Infomap without core nodes (Node ID 1)")

#----------id=108-------------#
g3_del_core <- induced_subgraph(g1, neighbors(g1, 108))

fg2 <- cluster_fast_greedy(g3_del_core)
modularity(fg2)#0.4581271
plot(g3_del_core, mark.groups=groups(fg2), edge.arrow.size=.5, 
     vertex.color=fg2$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Fast-Greedy without core nodes (Node ID 108)")

eb2 <- cluster_edge_betweenness(g3_del_core)
modularity(eb2)#0.5213216
plot(g3_del_core, mark.groups=groups(eb2), edge.arrow.size=.5, 
     vertex.color=eb2$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Edge-Betweenness without core nodes (Node ID 108)")

im2 <- cluster_infomap(g3_del_core)
modularity(im2)#0.5207887
plot(g3_del_core, mark.groups=groups(im2), edge.arrow.size=.5, 
     vertex.color=im2$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Infomap without core nodes (Node ID 108)")

#----------id=349-------------#
g4_del_core <- induced_subgraph(g1, neighbors(g1, 349))

fg3 <- cluster_fast_greedy(g4_del_core)
modularity(fg3)#0.2456918
plot(g4_del_core, mark.groups=groups(fg3), edge.arrow.size=.5, 
     vertex.color=fg3$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Fast-Greedy without core nodes (Node ID 349)")

eb3 <- cluster_edge_betweenness(g4_del_core)
modularity(eb3)#0.1505663
plot(g4_del_core, mark.groups=groups(eb3), edge.arrow.size=.5, 
     vertex.color=eb3$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Edge-Betweenness without core nodes (Node ID 349)")

im3 <- cluster_infomap(g4_del_core)
modularity(im3)#0.2448156
plot(g4_del_core, mark.groups=groups(im3), edge.arrow.size=.5, 
     vertex.color=im3$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Infomap without core nodes (Node ID 349)")

#----------id=484-------------#
g5_del_core <- induced_subgraph(g1, neighbors(g1, 484))

fg4 <- cluster_fast_greedy(g5_del_core)
modularity(fg4)#0.5342142
plot(g5_del_core, mark.groups=groups(fg4), edge.arrow.size=.5, 
     vertex.color=fg4$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Fast-Greedy without core nodes (Node ID 484)")

eb4 <- cluster_edge_betweenness(g5_del_core)
modularity(eb4)#0.5154413
plot(g5_del_core, mark.groups=groups(eb4), edge.arrow.size=.5, 
     vertex.color=eb4$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Edge-Betweenness without core nodes (Node ID 484)")

im4 <- cluster_infomap(g5_del_core)
modularity(im4)#0.5434437
plot(g5_del_core, mark.groups=groups(im4), edge.arrow.size=.5, 
     vertex.color=im4$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Infomap without core nodes (Node ID 484)")

#----------id=1087-------------#
g6_del_core <- induced_subgraph(g1, neighbors(g1, 1087))

fg5 <- cluster_fast_greedy(g6_del_core)
modularity(fg5)#0.1481956
plot(g6_del_core, mark.groups=groups(fg5), edge.arrow.size=.5, 
     vertex.color=fg5$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Fast-Greedy without core nodes (Node ID 1087)")

eb5 <- cluster_edge_betweenness(g6_del_core)
modularity(eb5)#0.0324953
plot(g6_del_core, mark.groups=groups(eb5), edge.arrow.size=.5, 
     vertex.color=eb5$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Edge-Betweenness without core nodes (Node ID 1087)")

im5 <- cluster_infomap(g6_del_core)
modularity(im5)#0.02737159
plot(g6_del_core, mark.groups=groups(im5), edge.arrow.size=.5, 
     vertex.color=im5$membership, vertex.label=NA, vertex.size=4,  
     main="Community Structure using Infomap without core nodes (Node ID 1087)")
