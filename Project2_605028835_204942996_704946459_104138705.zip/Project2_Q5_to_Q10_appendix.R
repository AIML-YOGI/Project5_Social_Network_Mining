#Project 2  - Social Network Mining
library(igraph)
setwd("C:/Users/anupams/OneDrive - Microsoft/Study/Summer 2018/Project 2")

fbData = read.table("Data/facebook_combined.txt")
print(fbData)

fbData = as.matrix(fbData)
fbData[,1] = as.character(fbData[,1])
fbData[,2] = as.character(fbData[,2])

fbGraph = graph_from_edgelist(fbData[,1:2], directed=FALSE)


## Question 5 - Create the personalized Network for user whose ID =1 How Many edges and Nodes does the personalized network have ?

fbGraph_1 = induced.subgraph(fbGraph, c(1, neighbors(fbGraph, 1)))

node_size = rep(4, vcount(fbGraph_1))
node_size[1] = 8
node_color = rep("blue", vcount(fbGraph_1))
node_color[1] = "hotpink"
                
plot(fbGraph_1, vertex.size = node_size, vertex.color = node_color, vertex.label= NA, edge.arrow.size = 0, main="Personalized Network for the User whose ID = 1")

vcount(fbGraph_1)
ecount(fbGraph_1)

## Question 6 :  Diameter of the personlized Network , upper and lower bound

diameter(fbGraph_1)
get_diameter(fbGraph_1)
farthest_vertices(fbGraph_1)

## Question 8 - How many core nodes, core nodes are one that has > 200 neighbors

## Let us get the node Id for core Nodes
coreId = which(neighborhood.size(fbGraph,1,nodes=V(fbGraph) ) > 201)

## Let us print these ID and number of such nodes
print(coreId)
print(length(coreId))

## Now let us get the averge degree of these core nodes

avgDeg = mean(degree(fbGraph, v=V(fbGraph)[coreId]))
print(avgDeg)


## Question 9 - For each of the above core node's personalized network, aand the community struc-ture using Fast-Greedy, Edge-Betweenness, and Infomap community detection algorithms. Compare
##the modularity scores of the algorithms. For visualization purpose, display the community structure
##of the core node's personalized networks using colors. Nodes belonging to the same community
##should have the same color and nodes belonging to dierent communities should have dierent
##color. In this question, you should have 15 plots in total.

coreIds = c(1,108,349,484,1087)

fbGraph_N = make_ego_graph(fbGraph,1,nodes=V(fbGraph)[coreIds])

for (i in 1:5) {
 cat("CoreNodeId:", coreIds[i], "\n")
  
  ## Let us do Fast Greedy Algorithm first
  fastG = cluster_fast_greedy(fbGraph_N[[i]])
  cat(" ", "Modularity for Fast Greedy:", modularity(fastG),"\n")
  ## Now let us plot the community structure
  fastG_Node_Color = fastG$membership + 3
  plot(fbGraph_N[[i]], mark.groups=groups(fastG),edge.arrow.size= 0.6, vertex.color = fastG_Node_Color,vertex_size = 4, vertex.label=NA, 
    main = paste("Community Strucutre for (Fast Greedy, Core Node", coreIds[i], ")", collapse = "") )                 
      
  ## Let us now do for Edge Betweennes
  edgeB = cluster_edge_betweenness(fbGraph_N[[i]])
  cat(" ", "Modularity for Edge Betweenness:", modularity(edgeB), "\n")
  edgeB_Node_Color = edgeB$membership + 3
  plot(fbGraph_N[[i]], mark.groups=groups(edgeB),edge.arrow.size= 0.6, vertex.color = edgeB_Node_Color,vertex_size = 4, vertex.label=NA, 
       main = paste("Community Strucutre for (EdgeBetweenness, Core Node", coreIds[i], ")", collapse = "") )  
  
  ## Let us now do for Edge Betweennes
  
 infoM = cluster_infomap(fbGraph_N[[i]])
  cat(" ", "Modularity for Info Map:", modularity(infoM), "\n")
  InfoM_Node_Color = infoM$membership + 3
  plot(fbGraph_N[[i]], mark.groups=groups(infoM),edge.arrow.size= 0.6, vertex.color = InfoM_Node_Color,vertex_size = 4, vertex.label=NA, 
       main = paste("Community Strucutre for (InfoMap, Core Node", coreIds[i], ")", collapse = "") )  
  cat("\n")
  }

## Question 10 In this question we will remove the core Node from the community network

coreIds = c(1,108,349,484,1087)

for (i in 1:5) {
  cat("CoreNodeId:", coreIds[i], "\n")
  
  fbGraph_I = induced_subgraph(fbGraph, neighbors(fbGraph, coreIds[i]))
  ## Let us do Fast Greedy Algorithm first
  fastG = cluster_fast_greedy(fbGraph_I)
  cat(" ", "Modularity for Fast Greedy:", modularity(fastG),"\n")
  ## Now let us plot the community structure
  fastG_Node_Color = fastG$membership + 3
  plot(fbGraph_N[[i]], mark.groups=groups(fastG),edge.arrow.size= 0.6, vertex.color = fastG_Node_Color,vertex_size = 4, vertex.label=NA, 
       main = paste("Community Strucutre for (Fast Greedy, Removed Core Node", coreIds[i], ")", collapse = "") )                 
  
  ## Let us now do for Edge Betweennes
  edgeB = cluster_edge_betweenness(fbGraph_I)
  cat(" ", "Modularity for Edge Betweenness:", modularity(edgeB), "\n")
  edgeB_Node_Color = edgeB$membership + 3
  plot(fbGraph_N[[i]], mark.groups=groups(edgeB),edge.arrow.size= 0.6, vertex.color = edgeB_Node_Color,vertex_size = 4, vertex.label=NA, 
       main = paste("Community Strucutre for (EdgeBetweenness, Removed Core Node", coreIds[i], ")", collapse = "") )  
  
  ## Let us now do for Edge Betweennes
  
  infoM = cluster_infomap(fbGraph_I)
  cat(" ", "Modularity for Info Map:", modularity(infoM), "\n")
  InfoM_Node_Color = infoM$membership + 3
  plot(fbGraph_N[[i]], mark.groups=groups(infoM),edge.arrow.size= 0.6, vertex.color = InfoM_Node_Color,vertex_size = 4, vertex.label=NA, 
       main = paste("Community Strucutre for (InfoMap, Removed Core Node", coreIds[i], ")", collapse = "") )  
  cat("\n")
  
}

